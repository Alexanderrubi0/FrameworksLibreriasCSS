$("document").ready(function () {
  $("a[href$=.pdf]").after("<img src='http://placehold.it/16x16' align='absbottom' />")


});


$(document).foundation();
